package com.tpe.controller;

import com.tpe.domain.Student;
import com.tpe.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*@Controller//MVC de bu şekilde yaptık. Student entity ile gelecek controller class im, request leri karşılayacak.
            // view yani görsel var. view diye bir objem olmayacak. REST FULL API yapıyorum. bu yüzden @Contoller değil, @RestController annotation kullanacağım.*/

@RestController
@RequestMapping("/students")// http://localhost:8080/students //Dispatcher Servlet a sana /students and point ile bir request geldiğinde ... diyorum. @RequestMappin: Student entity si ile alakalı controller
public class StudentController {

    @Autowired//field injection StudentService i StudentController a,yani service bağımlılığını buraya enjekte ettik. new lemeden kullanabilirim.
    private StudentService studentService;

    //!!! Butun ogrencileri getirelim
    //Rest full api de request içinde minumum da iki şey gitmesi lazım: endpoint + http method(get, post...)
    @GetMapping//Burada get işlemi yapacağım - //  http://localhost:8080/students + GET
    public ResponseEntity<List<Student>> getAll(){//esnek bir yapı, uzunluğu değişken, hiç elemanı olmayan ya da çok elemanı olabilen bir yapı List kullanacağım.

        //tek görev gelen request i service e göndermek
        List<Student> students = studentService.getAll();
        return ResponseEntity.ok(students);//List<Student> + HTTP.Status code = 200
    }

    /*
   ResponseEntity<List<Student>>
   response olarak ne göndereceğim: Students + StatusCode(401, 404...) - Java kodları ile map kullanarak çözebilirdim.
   map in ilk kısmı Students, ikinci kısmı StatusCode. ama Spring Framework ResponseEntity ile daha kolya çözmemizi sağlar.
   Madem restfull api yapıyorsun.
   entity classlar dışında statuscode da göndereceksin
   o zaman bu işi kolay bir şekilde yap ResponseEntity yapısı ile kolaylıkla gönderebilirsin demiş Spring Framework.
   Spring Boot, Entity lere statuscode larını göndermek işini kolaylaştırılmış bir sınıf : ResponseEntity
     */

}


/*
@RestController : özelleştirilmiş bir controller. Rest mimarisine uygun.
sadece response göndermeyeceğim onun yanında http status kodlarını 200, 201, 300, 401, 404 gibi status kodlarını da göndereceğim demiş oluyoruz Spring Framework e.

@RequestMapping("/students") ile Handler Mapping e: sana bir request bir andpoint gelirse (request = restfull api de andpoint)
ve sonu /students ile bitecekse (devamı olabilir /students in önemli değil) bu controller sayfama dallan
gelen request in karşılığı buradaki methodlarda mutlaka var.
//http://localhost:8080/students ile başlayan endpoint beni bu class a getirecek

-------------
Controller, Service class ile görüşecek, bir nevi ona bağımlı.
Service class ını "new lemeden", StudentService class ini StudentController classina enjekte ederek kullanacağım => field injection
Spring Framework dışında olsaydım StudentService i StudentController class içinde new leyerek oluşturmam gerekirdi => StudentService stdService=new StudentService();
Spring Framework kullanmaktaki amacım DI.
 */