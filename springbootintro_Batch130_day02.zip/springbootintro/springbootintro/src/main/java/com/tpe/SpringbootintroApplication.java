package com.tpe;

import com.tpe.domain.Student;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootintroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootintroApplication.class, args);



	}

}

