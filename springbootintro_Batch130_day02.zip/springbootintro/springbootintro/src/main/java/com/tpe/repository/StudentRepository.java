package com.tpe.repository;

import com.tpe.domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository//Opsiyonel. Spring Framework, StudentRepository i JpaRepository den extend ettiğimize göre bu interface in zaten "repository" olduğunu anlıyor. okunurluk için @Repository ekliyoruz.
public interface StudentRepository extends JpaRepository<Student, Long> {
}


//<Student, Long> : StudentRepository nin kullandığı entity class ismi ve unique olan @Id ile işaretlediğim field in data type ini istiyor JpaRepository