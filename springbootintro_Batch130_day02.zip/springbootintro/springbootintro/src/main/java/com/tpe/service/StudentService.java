package com.tpe.service;


import com.tpe.domain.Student;
import com.tpe.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service//Spring Framework e bu benim service class im dedim.
public class StudentService {

    @Autowired//StudentRepository i StudentService e enjekte ettim.
    private StudentRepository studentRepository;

    public List<Student> getAll() {
        return studentRepository.findAll();//repoya gönderdim.
    }
}
