package com.tpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootintroApplicationTests {

	@Test
	void contextLoads() {
	}

}
