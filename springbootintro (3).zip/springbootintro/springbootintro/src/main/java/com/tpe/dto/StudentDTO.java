package com.tpe.dto;

import com.tpe.domain.Student;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentDTO {

    //DB ile alakalı olmayan her şeyi sildim. DB e kadar gitmeyecek, Service Class inda değişecek.
    //name yerine firstName yazdık, değiştirdik burada!!
    private Long id;

    @NotNull(message = "first name can not be null")
    @NotBlank(message = "first name can not be white space")
    @Size(min=2, max=25, message = "first name'${validatedValue}' must be between {min} and {max} long")
    private String firstName;//POJO da name, burada firstName
    private String lastName;
    private Integer grade;
    @Email(message = "Provide valid email")
    private /*final*/ String email;
    private /*final*/ String phoneNumber;
    private LocalDateTime createDate = LocalDateTime.now();

    /*
    constructor-------------------------------------------------------------------------------------------------------
    StudentDTO nun constructor u ama parametresi POJO class.
    DTO class i oluştururken parametre olarak POJO class i göndereceğim bana dönen değer DTO olacak.
    Bu constructor:
    DTO class imi üretirken bir const cagiriyorum. Bu constructor ın parametresine POJO class i gonderiyorum.
    Bir dönüşüm, mapleme yapmış oluyorum.
    DTO objesi üretirken eger bu constructor ı kullanırsan ve içerisinde parametre olarak da POJO class i verirsen
    bu constructor otomatikmen POJO class i alacak DTO formatına çevirecek.
     */
    public StudentDTO(Student student){
        this.id = student.getId();
        this.firstName = student.getName();
        this.lastName = student.getLastName();
        this.grade = student.getGrade();
        this.email = student.getEmail();
        this.phoneNumber = student.getPhoneNumber();
        this.createDate = student.getCreateDate();
    }


}
