package com.tpe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Setter
@NoArgsConstructor
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonProperty("bookName")//sadece book class inin JSON cıktısındaki name field ini "bookName" olarak gösteriyor. DB de, Core Java tarafındaki ismi hala "name"
    private String name;


    //1 ogrencinin +1 book u olsun istiyorum
    @JsonIgnore//Student tan gelir ve bir daha Student a gitmez. döngüyü burada kırdım. StackOverFlow hatası almamak için
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    //Getter
    public Long getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public Student getStudent(){
        return student;
    }
}
