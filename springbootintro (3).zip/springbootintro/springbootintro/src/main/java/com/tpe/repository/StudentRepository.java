package com.tpe.repository;

import com.tpe.domain.Student;
import com.tpe.dto.StudentDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository//Opsiyonel. Spring Framework, StudentRepository i JpaRepository den extend ettiğimize göre bu interface in zaten "repository" olduğunu anlıyor. okunurluk için @Repository ekliyoruz.
public interface StudentRepository extends JpaRepository<Student, Long> {
    boolean existsByEmail(String email);
    List<Student> findByLastName(String lastName);

    //!!! Controller daki get All Student By Grade icin olusturduk JPQL ve SQL -----------------------------------------
    //JPQL
    @Query("SELECT s FROM Student s WHERE s.grade=:pGrade")
    List<Student> findAllEqualsGrade(@Param("pGrade") Integer grade);

    //SQL  ==> hata alıyorum açık olduğunda ------> incele!!!
//    @Query(value = "SELECT * FROM Student s WHERE s.grade=pGrade)", nativeQuery = true)
//    List<Student> findAllEqualsGradeWithSQL(@Param("pGrade") Integer grade);

    //JPQL mucizesi ile POJO - DTO donusumu ----------------------------------------------------------------------------

    //asağıdaki query nin çalışması için DTO ve POJO class taki field lar aynı olmalı. best practice DTO da ihtiyacım kadar data olması ama bu methodda tüm datalar olmalı
    //yani otomatik map leme işlemi için DTO ve POJO class ta tüm field ların eşit olması gerekiyor.
    // Spring Framework ya da data JPA bu method u tanımıyor. custom bir query yazarak tanıtıyorum. //StudentDTO daki parametreli constructor ı cağırdım.
    //repo katmanında direkt map leme yapacak, objeyi alacak DTO ya çevirecek bunu SQL ile yapamam JPQL ile yapmak zorundayım => new com.tpe.dto. --> DTO nun constructor ını çağırıyor.
    @Query("SELECT new com.tpe.dto.StudentDTO(s) FROM Student s WHERE s.id=:id")
    Optional<StudentDTO> findStudentDTOById(@Param("id") Long id); //bu method çalıştığı anda bana Optional DTO lar geliyor, map leme işlemini Repository de yapıyorum.


}

/*
POJO class Repository veya Service katmanında DTO class a dönüştürülebilir.
DTO class Service katmanında POJO ya çevrilmelidir. Repository de bu işi yapacak komutum yok.
Bussines logic katı Service katı olduğu için core Java kodlarıyla yapabiliyorum. POJO haliyle DB ye gidebilir.
Projelerin genelinde dönüşüm SERVİCE te yapılır.
 */

//<Student, Long> : StudentRepository nin kullandığı entity class ismi ve unique olan @Id ile işaretlediğim field in data type ini istiyor JpaRepository
//Repository, projedeki en sakin kat...
