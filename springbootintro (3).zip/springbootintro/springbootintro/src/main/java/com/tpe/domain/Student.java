package com.tpe.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter//class in tüm getter methodları devreye girdi
@Setter//class in tüm setter methodları devreye girdi
@AllArgsConstructor//parametreli const devreye girdi
//@RequiredArgsConstructor//final olarak yazdıklarımızdan constructor üretir. id nin const da çağırılmasını istemiyorum.
// id ve createDate  hariç tüm değişkenleri final ile setliyorum. artık id ve createDate den const üretmiyor.
@NoArgsConstructor//parametresiz const devreye girdi
@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //@Setter(AccessLevel.NONE)//id nin setter ı çalışmasın, id setlenmesin
    //@Getter
    private Long id;

    @NotNull(message = "first name can not be null")
    @NotBlank(message = "first name can not be white space")
    @Size(min=2, max=25, message = "first name'${validatedValue}' must be between {min} and {max} long")
    @Column(nullable = false, length = 25)//null olmasın, uzunluk max 25 olsun. bu kontrolü Repository de yapar.
    // Controller da kontrol etmesini istersem (nutnull, size gibi) validation kütüphanesi bu kontrolü controller tarafında yapar. iki defa kontrol edilmiş olur.
    //@Getter
    //@Setter
    //@Data : getter, setter, toString, const... paketlenmiş olarak getirir.
    private /*final*/ String name;

    @Column(nullable = false, length = 25)//name de yaptığım her şeyi burada da yapmalıyım. süreden dolayı yapmadık.
    private /*final*/ String lastName;

    private /*final*/ Integer grade;

    @Column(nullable = false, unique = true)
    @Email(message = "Provide valid email")//@ işareti ve bir yerden sonra . ve sonrası var mı ona bakıyor. @gmail.com gibi
    private /*final*/ String email;

    private /*final*/ String phoneNumber;//aritmetik işlem yapmayacaksam String giriyorum sayısal ifadeleri


    //@Setter(AccessLevel.NONE)//createDate setlenmesin
    private LocalDateTime createDate = LocalDateTime.now();//oluşturulan kişinin oluşturulduğu an.


    // 1 ogrencinin +1 book u olsun istiyorum
    @OneToMany(mappedBy = "student")
    private List<Book> book = new ArrayList<>();



//    //getter - setter --------------------------------------------------------------------------------------------------
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getLastName() {
//        return lastName;
//    }
//
//    public void setLastName(String lastName) {
//        this.lastName = lastName;
//    }
//
//    public Integer getGrade() {
//        return grade;
//    }
//
//    public void setGrade(Integer grade) {
//        this.grade = grade;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getPhoneNumber() {
//        return phoneNumber;
//    }
//
//    public void setPhoneNumber(String phoneNumber) {
//        this.phoneNumber = phoneNumber;
//    }
//
//    public LocalDateTime getCreateDate() {
//        return createDate;
//    }
//
//    public void setCreateDate(LocalDateTime createDate) {
//        this.createDate = createDate;
//    }
//
//    //constructor ------------------------------------------------------------------------------------------------------
//
//    public Student(Long id, String name, String lastName, Integer grade, String email, String phoneNumber, LocalDateTime createDate) {
//        this.id = id;
//        this.name = name;
//        this.lastName = lastName;
//        this.grade = grade;
//        this.email = email;
//        this.phoneNumber = phoneNumber;
//        this.createDate = createDate;
//    }
//
//    public Student() {
//    }
//
//    //toString ---------------------------------------------------------------------------------------------------------
//
//    @Override
//    public String toString() {
//        return "Student{" +
//                "id=" + id +
//                ", name='" + name + '\'' +
//                ", lastName='" + lastName + '\'' +
//                ", grade=" + grade +
//                ", email='" + email + '\'' +
//                ", phoneNumber='" + phoneNumber + '\'' +
//                ", createDate=" + createDate +
//                '}';
//    }


}
//-------------------------------------------
//@Entity
//Hibernate ile tek etkileşim kurduğumuz yer entity class lar.
// Başka hiçbir yerde Hibernate ile ilgili bir şey yazmayacağız, Spring Boot otomatik yapacak.
//session, sessionfactory, commit... göz önüne gelsin. datayı persist etmek için yapacağım her şeyi Spring Boot yapacak.
// tek yapmam gereken entity class i işaretlemek.