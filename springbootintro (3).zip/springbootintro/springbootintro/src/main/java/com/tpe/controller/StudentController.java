package com.tpe.controller;

import com.tpe.domain.Student;
import com.tpe.dto.StudentDTO;
import com.tpe.service.StudentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SimpleTimeZone;

/*@Controller//MVC de bu şekilde yaptık. Student entity ile gelecek controller class im, request leri karşılayacak.
            // view yani görsel var. view diye bir objem olmayacak. REST FULL API yapıyorum. bu yüzden @Contoller değil, @RestController annotation kullanacağım.*/

@RestController
@RequestMapping("/students")// http://localhost:8080/students //Dispatcher Servlet a sana /students and point ile bir request geldiğinde ... diyorum. @RequestMappin: Student entity si ile alakalı controller
public class StudentController {

    //!!! Logger -------------------------------------------------------------------------------------------------------
    Logger logger = LoggerFactory.getLogger(StudentController.class);//logger sınıfının instance i olan logger isimli bir objem var. new leme işlemini LoggerFactory yapıyor, newlemedim o yüzden.

    @Autowired//field injection StudentService i StudentController a,yani service bağımlılığını buraya enjekte ettik. new lemeden kullanabilirim.
    private StudentService studentService;

    //!!! Butun ogrencileri getirelim ----------------------------------------------------------------------------------
    //Rest full api de request içinde minumum da iki şey gitmesi lazım: endpoint + http method(get, post...)
    @GetMapping//Burada get işlemi yapacağım - //  http://localhost:8080/students + GET
    public ResponseEntity<List<Student>> getAll(){//esnek bir yapı, uzunluğu değişken, hiç elemanı olmayan ya da çok elemanı olabilen bir yapı List kullanacağım.

        //tek görev gelen request i service e göndermek
        List<Student> students = studentService.getAll();
        return ResponseEntity.ok(students);//List<Student> + HTTP-Status code = 200
    }

    //!!! Create new student -------------------------------------------------------------------------------------------
    @PostMapping //  http://localhost:8080/students + POST + JSON   (RESTFULL request i JSON ile alıyor, varsa JSON gerekiyorsa JSON gelecek bana, response de JSON ile gidecek.
    public ResponseEntity<Map<String, String>> createStudent(@Valid @RequestBody Student student){
        studentService.createStudent(student);//student  validation a takılmazsa create edilecek. dönen değerim yok burada.

        Map<String, String> map = new HashMap<>();
        map.put("message", "Student is created successfuly");
        map.put("status", "true");

        return new ResponseEntity<>(map, HttpStatus.CREATED);//data ve http status code u gönderdim.
    }

    //!!! Get a Student by ID via RequestParam -------------------------------------------------------------------------
    //best practice de +1 data alacaksam okunurluk adına RequestParam kullanmak daha mantıklı
    @GetMapping("/query")//http://localhost:8080/students/query?id=1 //diğer @GetMapping ile karışmaması için path i değiştiriyorum artık path http://localhost:8080/students/query + (@RequestParam("id") Long id) ile request in son hali ==> http://localhost:8080/students/query?id=1
    public ResponseEntity<Student> getStudent(@RequestParam("id") Long id){

        Student student = studentService.findStudent(id);
        return ResponseEntity.ok(student);// veya ok() methodu kullanmayıp ==>  return new ResponseEntity<>(map, HttpStatus.OK);
    }


    //!!! Get a Student by ID via PathVariable -------------------------------------------------------------------------
    @GetMapping("{id}")//http://localhost:8080/students/1 ==> best practice de tek data alacaksam PathVariable kullanmalıyım
    public ResponseEntity<Student> getStudentWithPath(@PathVariable("id") Long id){
        Student student = studentService.findStudent(id);
        return ResponseEntity.ok(student);
    }

    //!!! Delete Student with id ---------------------------------------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable("id") Long id){
        studentService.deleteStudent(id);

        //controller in bir diger gorevi gelen response u uygun formata cevirip client tarafına göndermek. bunun için:
        Map<String, String> map = new HashMap<>(); // bir map objesi
        map.put("message", "Student is deleted successfuly"); // bir mesaj key i, value su
        map.put("status", "true");// StatusCode true ya setledim ki 200 kodu gideceği önden belli olsun

        return new ResponseEntity<>(map, HttpStatus.OK);// veya       return ResponseEntity.ok(map); kullanabilirim.
    }

    //!!! Update Student -----------------------------------------------------------------------------------------------
    @PutMapping("{id}") //http://localhost:8080/students/1  ---> endPoint + id + update edecegim bilgiler JSON formatında + HTTP-Method
    public ResponseEntity<Map<String, String>> updateStudent (
            @PathVariable Long id, @RequestBody StudentDTO studentDTO){

        studentService.updateStudent(id, studentDTO);//DB deki hangi id li student bilgileri ne ile güncellenecek --> id, studentDTO

        Map<String, String> map = new HashMap<>();
        map.put("message", "Student is updated successfuly");
        map.put("status", "true");

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    //!!! pageable yapı-------------------------------------------------------------------------------------------------

    //pageable seklinde getAll method umuzu oluşturacağız
    //DB den aldığım veriyi parçalı olarak göndereceğim.
    //Pageable sınıfı, Page data tipini bilmem lazım.
    @GetMapping("/page") //http://localhost:8080/students/page?page=1&size=2&sort=name&direction=ASC ==> endpoint sonunda 4 data vereceğim, best practice @RequestParam kullanmak.
    public ResponseEntity<Page<Student>> getAllWithPage(//Objelerim Page data type inde generic olarak gelecek - Page yapısıyla bana bütün objelerimi getir
                                                        @RequestParam("page") int page, //kacinci sayfa gelsin -zorunlu
                                                        @RequestParam("size") int size, //sayfa basi kac urun -zorunlu
                                                        @RequestParam("sort") String prop, //hangi field a gore siralanacak -opsiyonel
                                                        @RequestParam("direction")Sort.Direction direction //siralama turu: büyükten kucuge/kucukten buyuge ASC veya DSC -opsiyonel
                                                        ){

        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, prop ));//pageable objesi oluşturdum.
        //student lar DB'den bana gelecek onları client'e pageable formatında göndermem lazım
        //service e direkt gidiyorum, ilgili method u çağırıyorum, pageable objeyi arguman olarak gönderiyorum
        Page<Student> studentPage = studentService.getAllWithPage(pageable);//pageable data türünde bir veriyi getAllWithPage methoduna gönderdim. Bana Page data türünde Student lar dönecek.

        return ResponseEntity.ok(studentPage);
    }

    //!!! Get By LastName//student i soy ismine göre getir --------------------------------------------------------------
    @GetMapping("/querylastname")
    public ResponseEntity<List<Student>> getStudentByLastName(@RequestParam("lastName") String lastName){
        List<Student> list = studentService.findStudent(lastName);
        return ResponseEntity.ok(list);
    }

    //!!! get All Student By Grade (JPQL(=Jav Persistance Query Language) yapı ile bu request i yazıyoruz )---------------
    @GetMapping("/grade/{grade}")//http://localhost:8080/students/grade/75 + GET
    public ResponseEntity<List<Student>> getStudentsEqualsGrade(@PathVariable ("grade") Integer grade){
        List<Student> list = studentService.findAllEqualsGrade(grade);
        return ResponseEntity.ok(list);
    }

    //!!! DB'den direkt DTO olarak datami almak istersem ?? ------------------------------------------------------------
    // DB'den POJO class gelir. Bu sefer dönüşümü Service'te değil, DB de yani Repository katında yapmak istiyorum.
    @GetMapping("/query/dto")// http://localhost:8080/students/query/dto?id=1 + GET
    public ResponseEntity<StudentDTO> getStudentDTO(@RequestParam("id") Long id){ // ==> bu iki id aynı şey değil. @RequestParam("id") -> endpoint ten gelen bilgiyi setlemek için kullandığım id
        StudentDTO studentDTO = studentService.findStudentDTOById(id);                                             //Long id -->  id yi map lemek için bu satırda değişken ismi olarak kullanacağım id, bunun yerine a da yazabilirim, değişken adı
        return ResponseEntity.ok(studentDTO);
    }

    //!!! view
     //loglamayı kullanacağım
    @GetMapping("/welcome") // http://localhost:8080/students/welcome + GET
    public String welcome(HttpServletRequest request){

        logger.warn("---------------------- Welcome{}", request.getServletPath());//gelen path i ekrana bas.
        return "Welcome to Student Controller";
    }



}
//+1 data alacağım için RequestParam ile parametreleri alıyorum
//bir uygulamada -hemen hemen- entity kadar DTO olur. client-DB arasında veri alış verişi olduğu için.

/*
DTO <---> POJO
Data Transfer Objesi kullandınız mı, neden DTO kullanmaya ihtiyacımız var?
Spring Boot, Spring MVC uygulamalarında DTO ya neden ihtiyacımız var?
Hız ve Güvenlik ten dolayı.
Client ten Service e data gelecekse DTO gelmek zorunda, Client tan Service e kadar gelen datalar DTO olmak zorunda
DB den bir şey geliyorsa, Service i geçtiği anda DTO ya cevirmek zorundayım.
Client dan Service e kadar DTO geldi, Service de DTO yu POJO ya çevirmezseniz DB ye kadar gelir ve kod patlar: bilgiler eski DB ye POJO olarak bilginin gitmesi lazım.
Client tarafından gelen DTO nun POJO ya çevrilmesi lazım çünkü DB ye gidiyor.
enterprice uygulamalar DTO <---> POJO dönüşümleriyle çalışır.

Senaryo client ten DB ye doğru giderken POJO ya dönmezse exception alırsınız.
DB den client a doğru giderken POJO'yu  DTO ya çevirmezseniz exception almazsınız ama "hız ve güvenlik" bilgisi yaşarsınız. tüm bilgiler gider.
 */

/*
path variable-----------
bir datayi path variable ile almaya kalkarsanız --> http://localhost:8080/students/1 path variable de böyle yazmanız yeterli
1'in id olduğunu kodu tasarlayan bilebilir ama dışarıdan bu endpoint e bakan bir kişi ne ile çağırıldığını anlayamaz.

requestparam-------------
aynı sorguyu request param ile yaparsanız daha okunaklıdır, 1'in hangi dataya ait olduğunu görebiliyorum.
http://localhost:8080/students/query?id=1

best practice: tek data istiyorsa kod okunurluğunu artırmak için request param kullanılır.
 */

/*
  Map<String, String> map = new HashMap<>(); => neden new ledim?
  bu objeyi sadece burada kullanacağız. çok sık kullanmayacağım bir yapıyı neden IoC container a göndereyim? gerek yok.
  Oluşturacağım objeyi tekrarlı kullanmayacaksam new leyip geçmeliyim.
 */

/*
@RequestBody: Gelen request in body kısmında bir JSON gelecek bana. Gelen JSON dosyayı Student POJO class da map le.
her bir field i tek tek JSON dan alıp map ler. AMA gelen JSON dosyalarını kontrol etmem lazım : JSON daki key, value değerlerini @Valid ile kontrol etmiş oluyorum.

request bir pakettir. body sinde JSON ile gelmesini beklediğim datalar olur. Java JSON ı anlamaz. jackson kütüphanesi bunu yapıyor. işaretlemem gerekiyor: @RequestBody.
//request in body sinde gelen dosyayı Student pojo class imla maple

@Valid:  annotation ını neden kullandım: gelen JSON datam bu Student a map lenecek ama Student taki field ı zorunlu tuttuğum validation lar var(@NotBlank, @NotNull...)
Student taki field larda zorunlu tuttuğum validationa tabi tutulmasını istediğim o datalarla valide ederek map lenmesini sağlıyorum.
Valide edemezse controller aşamasında request i geri çevirebilirim.
@Valid i yazmazsam Student ile maplemeye çalışır, oradaki name i mapleyemediği için null gelir, Repository katmanına kadar gider
oradaki repository katmanındaki @Column annotatinından kontrol yapar request geri döndürülür. app bu tip yanlış mimarılerden dolayı performanslı çalışmaz.
 */


//endpoint ler aynı bile olsa aynı endpointlerde 1 tane GET varsa veya 1 tane POST varsa problem yok.
//ama +1 @GetMapping veya @Postmapping varsa çakışır, hanlermapping hangi request i hangi method ile eşleştireceğini bilemez exception
//aynı endpoind ile farklı http methodları kullanabilirim.

/*
ResponseEntity<List<Student>>
response olarak ne göndereceğim: Students + StatusCode(401, 404...) - Java kodları ile map kullanarak çözebilirdim.
map in ilk kısmı Students, ikinci kısmı StatusCode. ama Spring Framework ResponseEntity ile daha kolya çözmemizi sağlar.
Madem restfull api yapıyorsun.
entity classlar dışında statuscode da göndereceksin
o zaman bu işi kolay bir şekilde yap ResponseEntity yapısı ile kolaylıkla gönderebilirsin demiş Spring Framework.
Spring Boot, Entity lere statuscode larını göndermek işini kolaylaştırılmış bir sınıf : ResponseEntity
*/
/*
@RestController : özelleştirilmiş bir controller. Rest mimarisine uygun.
sadece response göndermeyeceğim onun yanında http status kodlarını 200, 201, 300, 401, 404 gibi status kodlarını da göndereceğim demiş oluyoruz Spring Framework e.

@RequestMapping("/students") ile Handler Mapping e: sana bir request bir andpoint gelirse (request = restfull api de andpoint)
ve sonu /students ile bitecekse (devamı olabilir /students in önemli değil) bu controller sayfama dallan
gelen request in karşılığı buradaki methodlarda mutlaka var.
//http://localhost:8080/students ile başlayan endpoint beni bu class a getirecek

-------------
Controller, Service class ile görüşecek, bir nevi ona bağımlı.
Service class ını "new lemeden", StudentService class ini StudentController classina enjekte ederek kullanacağım => field injection
Spring Framework dışında olsaydım StudentService i StudentController class içinde new leyerek oluşturmam gerekirdi => StudentService stdService=new StudentService();
Spring Framework kullanmaktaki amacım DI.
 */