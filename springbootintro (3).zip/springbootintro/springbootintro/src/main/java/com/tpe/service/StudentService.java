package com.tpe.service;


import com.tpe.domain.Student;
import com.tpe.dto.StudentDTO;
import com.tpe.exception.ConflictException;
import com.tpe.exception.ResourceNotFoundException;
import com.tpe.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service//Spring Framework e bu benim service class im dedim.
public class StudentService {

    @Autowired//StudentRepository i StudentService e enjekte ettim.
    private StudentRepository studentRepository;

    public List<Student> getAll() {
        return studentRepository.findAll();//repoya gönderdim.
    }

    public void createStudent(Student student) {//bu istek gelecek ve DB ye kaydedilecek.
        if(studentRepository.existsByEmail(student.getEmail())){//emailunique mi diye kontrol ediyorum.
            throw new ConflictException("Email is already exists!!!");//custom exception oluşturdum.
        }
        studentRepository.save(student);
    }

    public Student findStudent(Long id) {
        return studentRepository.findById(id).orElseThrow(
                ()->new ResourceNotFoundException("Student not found with id : "+id));//yoksa fırlat.
    }

    public void deleteStudent(Long id) {

        Student student = findStudent(id);//yukarıdaki methodu kullandım. exception varsa oradan fırlayacak
        studentRepository.delete(student);
    }

    public void updateStudent(Long id, StudentDTO studentDTO) {
        //email DB de var mı??
        boolean emailExist = studentRepository.existsByEmail(studentDTO.getEmail());

        //istenilen id de Student var mı?
        Student student = findStudent(id);

        //------------------------------- senaryolar if iceriginde olusturuldu.
        if(emailExist && ! studentDTO.getEmail().equals(student.getEmail())){
            throw new ConflictException("Email is already exist");
        }

        /*
           senaryo 1 : kendi email mrc , mrc girdim  (update olur)
        ** senaryo 2 : kendi emali mrc , ahmt gidim db de zaten var.  (exception)
           senaryo 3 : kendi email mrc , mhmt ve DB de yok (update olur)

         */

        //DTO 'yu POJO ya çevireceğim, DTO dan gelen bilgileri POJO class a setliyorum.
        student.setName(studentDTO.getFirstName());
        student.setLastName(studentDTO.getLastName());
        student.setGrade(studentDTO.getGrade());
        student.setEmail(studentDTO.getEmail());
        student.setPhoneNumber(studentDTO.getPhoneNumber());

        studentRepository.save(student);//güncel Student POJO class i persist ediyorum save method ile


    }

    public Page<Student> getAllWithPage(Pageable pageable) {

        return studentRepository.findAll(pageable);
    }


    public List<Student> findStudent(String lastName){
        return studentRepository.findByLastName(lastName);
    }
    public List<Student> findAllEqualsGrade(Integer grade) {
        return studentRepository.findAllEqualsGrade(grade);
    }

    //Task te DB'den direkt DTO gelmesini istediğim için bu katmanda bir dönüşüm işlemi yapmıyorum---------------------
    public StudentDTO findStudentDTOById(Long id) {

        return studentRepository.findStudentDTOById(id).orElseThrow(()->
                new ResourceNotFoundException("Student not found with id: " + id));
    }
}



//student.setId(studentDTO.getId()); --> id yi DTO ya alamam. JSON formatıyla geliyor. kullanıcı id girebilir, başka kullanıcıların datalarını update edebilir, DB deki sistem dağılır. !!!



/*
DTO oluştururken field ları pas geçme işlemini nasıl yaparız?
DTO yu ihtiyaç duyulan field sayısı kadar POJO nun kopyasını oluşturuyorum.
Gelen Request te kaç tane field gerekliyse o field içerisinde olacak kadar DTO oluşturmam gerekiyor.
1- StudentDTO class indaki istediğimiz field ları silerek field i pas geçebiliriz
2- Service katında ilgili dataları setlemeyip gececeğiz.

Genelde hangi datalara ihtiyacım varsa o field larla DTO oluşturacağız => best practice
 */

/*
projemde mutlaka DTO class kullanacağım, DTO-POJO dönüşümünü nasıl yapacağım -------------------------------------------
1- Service e setleyerek yapacağım
2- DB ye gidip JPQL kullanarak setleme yapacağım
3- mapstrack gibi yapılar var. lombok gibi arka tarafta setleme yapıyor
 */

/*
-exception
throw new ConflictException("Email is already exists!!!"); => String bir ifade yazıyorum buraya. bbu hard code dur.
Java kodlarım içerisine böyle String bir ifade yazmam iyi değil, sıkıntılı bir durum.
bunu da bir yerden alması gerekir. Spring Boot bunun üzerine merkezi bir exception mekanizması getirmiş Backend de gösterecekmiş hoca.
 */

/*
existsBy...(acaba var mı) ve findBy...(onu bul)  ile başlayan tüm methodlar değiştirilebiliyor: existsByEmail, existsById..., findById...
dönen değeri boolean olan ya da find gibi datayı bul getir ama neye göre id ye mi, name e göre mi hepsi türetilebilir
neden Repository tarafını interface olarak oluşturduk? body si olmayan methodları yazıp geçiyorum.
methodun body sini yazmama gerek kalmıyor. bu yapı da interface sağlıyor. bundan sonra repository katmanım interface.
 */
